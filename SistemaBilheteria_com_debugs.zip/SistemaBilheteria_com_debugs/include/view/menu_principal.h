//
// Created by natan on 29/04/2025.
//

#ifndef MENU_PRINCIPAL_H
#define MENU_PRINCIPAL_H


#include "model/bilheteria.h"
#include "model/bilhete.h"
#include "common.h"
#include "view/menu.h"
#include "view/menu_gerencial.h"
#include "view/visual.h"

#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <conio.h>

void menu_principal();

#endif //MENU_PRINCIPAL_H
