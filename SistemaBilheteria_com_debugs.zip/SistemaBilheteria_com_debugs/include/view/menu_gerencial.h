//
// Created by natan on 29/04/2025.
//

#ifndef MENU_GERENCIAL_H
#define MENU_GERENCIAL_H

#include "view/menu.h"
#include "view/visual.h"

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

void menu_gerencial(Bilheteria *cinema);

#endif //MENU_GERENCIAL_H
