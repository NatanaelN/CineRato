#include "view/menu_principal.h"


void main() {
    menu_principal();

}