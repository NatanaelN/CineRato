//
// Created by natan on 29/04/2025.
//

#ifndef STORAGE_H
#define STORAGE_H

#include <stdio.h>

#include "model/bilhete.h"
#include "model/bilheteria.h"

void meusBilhetes(const Bilheteria *bilheteria, const int indice);

#endif //STORAGE_H
